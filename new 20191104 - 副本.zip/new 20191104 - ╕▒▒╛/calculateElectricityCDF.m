function CDF = calculateElectricityCDF(mpc,interruptionTime,customerType)
%UNTITLED Summary of this function goes here
%  userType: 1=Industry, 2=Commercial, 3=Large industry, 
%           4= Public, 5=Agriculture, 6=Residential
%% calculate nodal IC curve
nodalLCeCurve(1,:) = mpc.LCecost(1,:);
nodalLCeCurve = [nodalLCeCurve; mpc.LCecost(customerType+1,:)];
CDF = unitLCeCostCalculation(interruptionTime,nodalLCeCurve);
% CDF=0;
%% call other functions
    function [cost] = unitLCeCostCalculation(interuptionTime,nodalLCeCurve)
    %UNTITLED2 Summary of this function goes here
    %   Detailed explanation goes here
    %% 
    t = nodalLCeCurve(1,:);
    c = nodalLCeCurve(2,:);
    pieceIndexHead = find(interuptionTime>=t, 1, 'last' );
    pieceIndexTail = pieceIndexHead + 1;
    if pieceIndexTail <= size(nodalLCeCurve,2)
        cost = c(pieceIndexHead) + (c(pieceIndexTail) - c(pieceIndexHead)) ...
        / (t(pieceIndexTail) - t(pieceIndexHead)) * (interuptionTime - t(pieceIndexHead));
    else
        cost = c(end);
    end
    end
end

