function addTransient = adjustTimeScaleOfTransientResult1st(transientResult1st,nt,dt,nGl)
timePoint1st = [1/12:1/12:4] * 3600;
timePointTransient = dt:dt:(nt*dt);
for i = 1:size(timePointTransient,2)
    if timePointTransient(i) <= timePoint1st(end)
        fromTime = max(find(timePoint1st<=timePointTransient(i))); toTime = fromTime + 1;
        for m = 1:nGl
        addTransient.P{m}(i,:) = transientResult1st.P{m}(fromTime,:) * (timePointTransient(i)-timePoint1st(fromTime))/(timePoint1st(toTime)-timePoint1st(fromTime))...
            + transientResult1st.P{m}(toTime,:) * (timePoint1st(toTime)-timePointTransient(i))/(timePoint1st(toTime)-timePoint1st(fromTime));
        addTransient.Q{m}(i,:) = transientResult1st.Q{m}(fromTime,:) * (timePointTransient(i)-timePoint1st(fromTime))/(timePoint1st(toTime)-timePoint1st(fromTime))...
            + transientResult1st.Q{m}(toTime,:) * (timePoint1st(toTime)-timePointTransient(i))/(timePoint1st(toTime)-timePoint1st(fromTime));
        end
    else
        for m = 1:nGl
        addTransient.P{m}(i:nt,:) = repmat(transientResult1st.P{m}(end,:),nt-i+1,1);
        addTransient.Q{m}(i:nt,:) = repmat(transientResult1st.Q{m}(end,:),nt-i+1,1);
        end
    end
        
   
end
end