matpower-extras
===============

MATPOWER Extras - contributed and/or unsupported MATPOWER-related code

To install, simply place the contents of this repository in a directory
named `extras` inside the MATPOWER install directory `<MATPOWER>` and
re-run `install_matpower`.
