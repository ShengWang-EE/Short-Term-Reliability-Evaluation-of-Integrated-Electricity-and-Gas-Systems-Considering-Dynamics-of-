function the_product = rithmaticker_timeser(varargin)
the_product = prod(cell2mat({varargin{:}}));
